﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;
using System.Numerics;
using System.Security.Policy;

namespace DSPAlgorithms.Algorithms
{
    public class FastCorrelation : Algorithm
    {
        public Signal InputSignal1 { get; set; }
        public Signal InputSignal2 { get; set; }
        public List<float> OutputNonNormalizedCorrelation { get; set; }
        public List<float> OutputNormalizedCorrelation { get; set; }

        public override void Run()
        {
            OutputNonNormalizedCorrelation = new List<float>();
            OutputNormalizedCorrelation = new List<float>();
            int auto_corr = 0;
            if (InputSignal2 == null)
            {
                //Filling signal 2
                InputSignal2 = new Signal(new List<float>(), InputSignal1.Periodic);
                for (int i = 0; i < InputSignal1.Samples.Count; i++)
                {
                    InputSignal2.Samples.Add(InputSignal1.Samples[i]);
                }
                auto_corr = 1;
            }

            //DFT For first signal with conjugate
            List<Complex> List1 = new List<Complex>();
            DiscreteFourierTransform DFT_sig1 = new DiscreteFourierTransform();
            DFT_sig1.InputTimeDomainSignal = new DSPAlgorithms.DataStructures.Signal(InputSignal1.Samples, InputSignal1.Periodic);
            DFT_sig1.Run();

            for (int i = 0; i < DFT_sig1.OutputFreqDomainSignal.FrequenciesAmplitudes.Count; i++)
            {
                float real = DFT_sig1.OutputFreqDomainSignal.FrequenciesAmplitudes[i] * (float)Math.Cos(DFT_sig1.OutputFreqDomainSignal.FrequenciesPhaseShifts[i]);
                Complex res = new Complex(real, -1 * DFT_sig1.OutputFreqDomainSignal.FrequenciesAmplitudes[i] * (float)Math.Sin(DFT_sig1.OutputFreqDomainSignal.FrequenciesPhaseShifts[i]));

                List1.Add(res);
            }

            //DFT For second signal 
            List<Complex> List2 = new List<Complex>();
            DiscreteFourierTransform DFT_sig2 = new DiscreteFourierTransform();
            DFT_sig2.InputTimeDomainSignal = new DSPAlgorithms.DataStructures.Signal(InputSignal2.Samples, InputSignal2.Periodic);
            DFT_sig2.Run();

            for (int i = 0; i < DFT_sig2.OutputFreqDomainSignal.FrequenciesAmplitudes.Count; i++)
            {
                float real = DFT_sig2.OutputFreqDomainSignal.FrequenciesAmplitudes[i] * (float)Math.Cos(DFT_sig2.OutputFreqDomainSignal.FrequenciesPhaseShifts[i]);
                Complex res = new Complex(real, DFT_sig2.OutputFreqDomainSignal.FrequenciesAmplitudes[i] * (float)Math.Sin(DFT_sig2.OutputFreqDomainSignal.FrequenciesPhaseShifts[i]));

                List2.Add(res);
            }

            //Multiplying two signals
            List<float> amp = new List<float>();
            List<float> phase_shift = new List<float>();
            for (int i = 0; i < DFT_sig2.OutputFreqDomainSignal.FrequenciesAmplitudes.Count; i++)
            {
                Complex res = List1[i] * List2[i];
                amp.Add((float)res.Magnitude);
                phase_shift.Add((float)Math.Atan2(res.Imaginary, res.Real));
            }

            //Getting IDFT
            InverseDiscreteFourierTransform IDFT=new InverseDiscreteFourierTransform();
            var freq = new List<float> { 0, 1, 2, 3, 4, 5, 6, 7 };
            IDFT.InputFreqDomainSignal = new DSPAlgorithms.DataStructures.Signal(true, freq, amp, phase_shift);
            IDFT.Run();

            for (int i = 0; i < IDFT.OutputTimeDomainSignal.Samples.Count(); i++)
            {
                OutputNonNormalizedCorrelation.Add(IDFT.OutputTimeDomainSignal.Samples[i] / IDFT.OutputTimeDomainSignal.Samples.Count());
            }

            //Auto corr
            if (auto_corr == 1)
            {

                float sum_sig1 = 0, sum_sig2 = 0;
                for (int i = 0; i < InputSignal1.Samples.Count; i++)
                {
                    sum_sig1 += (float)Math.Pow(InputSignal1.Samples[i], 2);
                    sum_sig2 += (float)Math.Pow(InputSignal2.Samples[i], 2);
                }

                float norm = sum_sig1 * sum_sig2;
                norm = (float)Math.Sqrt(norm);
                norm /= InputSignal1.Samples.Count;

                if (InputSignal1.Periodic == true)
                {

                    for (int i = 0; i < IDFT.OutputTimeDomainSignal.Samples.Count(); i++)
                    {
                        float non_norm =(float) IDFT.OutputTimeDomainSignal.Samples[i] / IDFT.OutputTimeDomainSignal.Samples.Count();
                        OutputNormalizedCorrelation.Add((float)(non_norm / norm));
                    }
                        InputSignal2.Samples.Add(InputSignal2.Samples[0]);
                        InputSignal2.Samples.RemoveAt(0);
                }
                else
                {
                    float normalize = 0;
                    for (int i = 0; i < InputSignal1.Samples.Count; i++)
                    {
                        normalize += (float)Math.Pow(InputSignal1.Samples[i], 2);
                    }
                    normalize /= InputSignal1.Samples.Count;

                    for (int i = 0; i < IDFT.OutputTimeDomainSignal.Samples.Count(); i++)
                    {
                        float non_norm = (float)IDFT.OutputTimeDomainSignal.Samples[i] / IDFT.OutputTimeDomainSignal.Samples.Count();
                        OutputNormalizedCorrelation.Add((float)(non_norm / normalize));
                    }  
                        InputSignal2.Samples.RemoveAt(0);
                        InputSignal2.Samples.Add(0);

                }
            }

            //Cross corr
            else
            {
                float sum_sig1 = 0, sum_sig2 = 0;
                for (int i = 0; i < InputSignal1.Samples.Count; i++)
                {
                    sum_sig1 += (float)Math.Pow(InputSignal1.Samples[i], 2);
                    sum_sig2 += (float)Math.Pow(InputSignal2.Samples[i], 2);
                }

                float norm = sum_sig1 * sum_sig2;
                norm = (float)Math.Sqrt(norm);
                norm /= InputSignal1.Samples.Count;

                for (int i = 0; i < IDFT.OutputTimeDomainSignal.Samples.Count(); i++)
                {
                    float non_norm = (float)IDFT.OutputTimeDomainSignal.Samples[i] / IDFT.OutputTimeDomainSignal.Samples.Count();
                    OutputNormalizedCorrelation.Add((float)(non_norm / norm));
                }

            }
        }
    }
}