﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;

namespace DSPAlgorithms.Algorithms
{
    public class Normalizer : Algorithm
    {
        public Signal InputSignal { get; set; }
        public float InputMinRange { get; set; }
        public float InputMaxRange { get; set; }
        public Signal OutputNormalizedSignal { get; set; }

        public override void Run()
        {
            float result, min = InputSignal.Samples[0], max= InputSignal.Samples[0];
            min = InputSignal.Samples.Min();
            max = InputSignal.Samples.Max();
            List<float> norm = new List<float>();
            //for (int i = 0; i < InputSignal.Samples.Count; i++)
            //{
            //    if (InputSignal.Samples[i] < min)
            //        min = InputSignal.Samples[i];
            //    if (InputSignal.Samples[i] > max)
            //        max = InputSignal.Samples[i];
            //}
            for (int i = 0; i < InputSignal.Samples.Count; i++)
            {
                result = (InputMaxRange- InputMinRange)*((InputSignal.Samples[i] - min) / (max - min)) + InputMinRange;
                norm.Add(result);
            }
  
            OutputNormalizedSignal = new Signal(norm, false);
        }
    }
}
