﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;


namespace DSPAlgorithms.Algorithms
{
    public class AccumulationSum : Algorithm
    {
        public Signal InputSignal { get; set; }
        public Signal OutputSignal { get; set; }

        public override void Run()
        {
            float res;
            List<float> L = new List<float>();
            for (int i = 0; i < InputSignal.Samples.Count; i++)
            {
                res = 0;
                for (int j = i; j >= 0; j--)
                {
                    res += InputSignal.Samples[j];
                }
                L.Add(res);
            }
            OutputSignal = new Signal(L, false);
        }
    }
}
