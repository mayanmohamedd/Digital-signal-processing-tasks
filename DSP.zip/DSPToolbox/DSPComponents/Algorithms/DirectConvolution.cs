﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;

namespace DSPAlgorithms.Algorithms
{
    public class DirectConvolution : Algorithm
    {
        public Signal InputSignal1 { get; set; }
        public Signal InputSignal2 { get; set; }
        public Signal OutputConvolvedSignal { get; set; }

        /// <summary>
        /// Convolved InputSignal1 (considered as X) with InputSignal2 (considered as H)
        /// </summary>
        public override void Run()
        {
            int min = InputSignal1.SamplesIndices.Min() + InputSignal2.SamplesIndices.Min();
            int max = InputSignal1.SamplesIndices.Max() + InputSignal2.SamplesIndices.Max();

            List<float> L = new List<float>();
            List<int> index = new List<int>();
            float res;

            for (int n = min; n <= max; n++)
            {
                res = 0;
                for (int k = min; k < InputSignal1.Samples.Count(); k++)
                {
                    if (k < InputSignal1.SamplesIndices.Min() || k > InputSignal1.SamplesIndices.Max())
                        continue;
                    if ((n - k) < InputSignal2.SamplesIndices.Min() || (n - k) > InputSignal2.SamplesIndices.Max())
                        continue;
                   int ind1 = InputSignal1.SamplesIndices.IndexOf(k);
                   int ind2 = InputSignal2.SamplesIndices.IndexOf(n-k);
                   res += InputSignal1.Samples[ind1] * InputSignal2.Samples[ind2];
                }
                if (n == max && res == 0.0)
                {
                    continue;
                }
                L.Add(res);
                index.Add(n);
            }
                OutputConvolvedSignal = new Signal(L, index, false);


        }
    }
}