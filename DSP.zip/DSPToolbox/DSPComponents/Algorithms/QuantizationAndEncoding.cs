﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;

namespace DSPAlgorithms.Algorithms
{
    public class QuantizationAndEncoding : Algorithm
    {
        public int InputLevel { get; set; }
        public int InputNumBits { get; set; }
        public Signal InputSignal { get; set; }
        public Signal OutputQuantizedSignal { get; set; }
        public List<int> OutputIntervalIndices { get; set; }
        public List<string> OutputEncodedSignal { get; set; }
        public List<float> OutputSamplesError { get; set; }
        
        public override void Run()
        {

            OutputSamplesError = new List<float>();
            OutputEncodedSignal = new List<string>();
            OutputIntervalIndices = new List<int>();
            List<List<float>> Intervals = new List<List<float>>();
            List<float> Midpoints = new List<float>();
            List<float>quant = new List<float>();
            
            if (InputLevel == 0)
            {
                InputLevel = (int)Math.Pow(2, InputNumBits);
            }
            else if (InputNumBits == 0)
            {
                InputNumBits = (int)Math.Log(InputLevel, 2);
            }
            float delta = (InputSignal.Samples.Max() - InputSignal.Samples.Min()) / InputLevel;
            float min = InputSignal.Samples.Min();



            for (int i = 0; i < InputLevel; i++)
            {
                Intervals.Add(new List<float> { min, min + delta });
                min += delta;
            }


            for (int i = 0; i < InputLevel; i++)
            {
                Midpoints.Add((Intervals[i].Min() + Intervals[i].Max()) / 2);
            }



            for (int i = 0; i < InputSignal.Samples.Count; i++)
            {
                for (int j = 0; j < Intervals.Count; j++)
                {
                    if (InputSignal.Samples[i] >= Intervals[j].Min() && InputSignal.Samples[i] < Intervals[j].Max()+0.0001)
                    {
                        quant.Add(Midpoints[j]);
                        OutputEncodedSignal.Add(Convert.ToString(j, 2).PadLeft(InputNumBits, '0')); 
                        OutputIntervalIndices.Add(j + 1);
                        OutputSamplesError.Add((Midpoints[j] - InputSignal.Samples[i]));
                    }

                }
            }
            OutputQuantizedSignal = new Signal(quant, false);



        }
    }
}

