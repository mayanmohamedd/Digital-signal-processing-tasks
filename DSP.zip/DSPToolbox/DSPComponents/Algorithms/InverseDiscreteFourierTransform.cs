﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;

namespace DSPAlgorithms.Algorithms
{
    public class InverseDiscreteFourierTransform : Algorithm
    {
        public Signal InputFreqDomainSignal { get; set; }
        public Signal OutputTimeDomainSignal { get; set; }

        public override void Run()
        {
            OutputTimeDomainSignal = new Signal(new List<float>(), false);
            List<Complex> L = new List<Complex>();
            Complex c = new Complex();
            for (int i = 0; i < InputFreqDomainSignal.FrequenciesAmplitudes.Count; i++)
            {
                c = new Complex(InputFreqDomainSignal.FrequenciesAmplitudes[i] * Math.Cos(InputFreqDomainSignal.FrequenciesPhaseShifts[i]),
                               (InputFreqDomainSignal.FrequenciesAmplitudes[i] * Math.Sin(InputFreqDomainSignal.FrequenciesPhaseShifts[i])));
                L.Add(c);
            }
            for (int n = 0; n < InputFreqDomainSignal.FrequenciesAmplitudes.Count; n++)
            {
                Complex var=new Complex(); 
                for (int k = 0; k < InputFreqDomainSignal.FrequenciesAmplitudes.Count; k++)
                {

                    var += new Complex((Math.Cos(n*2*Math.PI*k/ InputFreqDomainSignal.FrequenciesAmplitudes.Count)),
                           (Math.Sin(n * 2 * Math.PI * k / InputFreqDomainSignal.FrequenciesAmplitudes.Count))) * L[k];
                }
                var = var / InputFreqDomainSignal.FrequenciesAmplitudes.Count;
                OutputTimeDomainSignal.Samples.Add((float)var.Real);

            }


        }
    }
}
