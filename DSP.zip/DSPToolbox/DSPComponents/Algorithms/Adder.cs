﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;

namespace DSPAlgorithms.Algorithms
{
    public class Adder : Algorithm
    {
        public List<Signal> InputSignals { get; set; }
        public Signal OutputSignal { get; set; }

        public override void Run()
        {
            //If Two Signals are not of the same length
            int MaxLen = 0;
            if (InputSignals[0].Samples.Count < InputSignals[1].Samples.Count)
                MaxLen = 1;
            if (MaxLen == 0)
            {
                for (int i = InputSignals[0].Samples.Count; i < InputSignals[1].Samples.Count; i++)
                {
                    InputSignals[1].Samples[i] = 0;
                }
            }
            else
            {
                for (int i = InputSignals[1].Samples.Count; i < InputSignals[0].Samples.Count; i++)
                {
                    InputSignals[0].Samples[i] = 0;
                }
            }
            List<float> Outputs = new List<float>();
            for (int i = 0; i < InputSignals[0].Samples.Count; i++)
            {
                float sum = InputSignals[0].Samples[i] + InputSignals[1].Samples[i];
                Outputs.Add(sum);
            }
            OutputSignal = new Signal(Outputs, false);
        }
    }
}