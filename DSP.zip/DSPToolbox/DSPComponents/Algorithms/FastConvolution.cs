﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;

namespace DSPAlgorithms.Algorithms
{
    public class FastConvolution : Algorithm
    {
        public Signal InputSignal1 { get; set; }
        public Signal InputSignal2 { get; set; }
        public Signal OutputConvolvedSignal { get; set; }

        /// <summary>
        /// Convolved InputSignal1 (considered as X) with InputSignal2 (considered as H)
        /// </summary>
        public override void Run()
        {
            int count = InputSignal1.Samples.Count + InputSignal2.Samples.Count - 1;
            OutputConvolvedSignal = new Signal(new List<float>(),false);
            for (int i = InputSignal1.Samples.Count; i < count; i++)
            {
                InputSignal1.Samples.Add(0);
            }
            for (int i = InputSignal2.Samples.Count; i < count; i++)
            {
                InputSignal2.Samples.Add(0);
            }

            //DFT For first signal
            List<Complex> List1 = new List<Complex>();
            DiscreteFourierTransform DFT_sig1 = new DiscreteFourierTransform();
            DFT_sig1.InputTimeDomainSignal = new DSPAlgorithms.DataStructures.Signal(InputSignal1.Samples, InputSignal1.Periodic);
            DFT_sig1.Run();

            for (int i = 0; i < DFT_sig1.OutputFreqDomainSignal.FrequenciesAmplitudes.Count; i++)
            {
                float real = DFT_sig1.OutputFreqDomainSignal.FrequenciesAmplitudes[i] * (float)Math.Cos(DFT_sig1.OutputFreqDomainSignal.FrequenciesPhaseShifts[i]);
                Complex res = new Complex(real, DFT_sig1.OutputFreqDomainSignal.FrequenciesAmplitudes[i] * (float)Math.Sin(DFT_sig1.OutputFreqDomainSignal.FrequenciesPhaseShifts[i]));

                List1.Add(res);
            }

            //DFT For second signal 
            List<Complex> List2 = new List<Complex>();
            DiscreteFourierTransform DFT_sig2 = new DiscreteFourierTransform();
            DFT_sig2.InputTimeDomainSignal = new DSPAlgorithms.DataStructures.Signal(InputSignal2.Samples, InputSignal2.Periodic);
            DFT_sig2.Run();

            for (int i = 0; i < DFT_sig2.OutputFreqDomainSignal.FrequenciesAmplitudes.Count; i++)
            {
                float real = DFT_sig2.OutputFreqDomainSignal.FrequenciesAmplitudes[i] * (float)Math.Cos(DFT_sig2.OutputFreqDomainSignal.FrequenciesPhaseShifts[i]);
                Complex res = new Complex(real, DFT_sig2.OutputFreqDomainSignal.FrequenciesAmplitudes[i] * (float)Math.Sin(DFT_sig2.OutputFreqDomainSignal.FrequenciesPhaseShifts[i]));

                List2.Add(res);
            }

            //Multiplying two signals
            List<float> amp = new List<float>();
            List<float> phase_shift = new List<float>();
            for (int i = 0; i < DFT_sig2.OutputFreqDomainSignal.FrequenciesAmplitudes.Count; i++)
            {
                Complex res = List1[i] * List2[i];
                amp.Add((float)res.Magnitude);
                phase_shift.Add((float)Math.Atan2(res.Imaginary, res.Real));
            }

            //Getting IDFT
            InverseDiscreteFourierTransform IDFT = new InverseDiscreteFourierTransform();
            var freq = new List<float> { 0, 1, 2, 3, 4, 5, 6, 7 };
            IDFT.InputFreqDomainSignal = new DSPAlgorithms.DataStructures.Signal(true, freq, amp, phase_shift);
            IDFT.Run();

            for (int i = 0; i < IDFT.OutputTimeDomainSignal.Samples.Count(); i++)
            {
                OutputConvolvedSignal.Samples.Add(IDFT.OutputTimeDomainSignal.Samples[i]);
            }
        }
    }
}
