﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;



namespace DSPAlgorithms.Algorithms
{
    public class DirectCorrelation : Algorithm
    {
        public Signal InputSignal1 { get; set; }
        public Signal InputSignal2 { get; set; }
        public List<float> OutputNonNormalizedCorrelation { get; set; }
        public List<float> OutputNormalizedCorrelation { get; set; }
        public override void Run()
        {
            List<float> L = new List<float>();
            float res;
            double sum_sig1 = 0, sum_sig2 = 0;
            float norm = 0;

            OutputNonNormalizedCorrelation = new List<float>();
            OutputNormalizedCorrelation = new List<float>();
            if (InputSignal2 == null)
            {
                InputSignal2 = new Signal(new List<float>(), InputSignal1.Periodic);
                for (int i = 0; i < InputSignal1.Samples.Count; i++)
                {
                    InputSignal2.Samples.Add(InputSignal1.Samples[i]);
                }

                for (int i = 0; i < InputSignal1.Samples.Count; i++)
                {
                    res = 0;
                    sum_sig1 = 0; sum_sig2 = 0; norm = 0;
                    for (int j = 0; j < InputSignal1.Samples.Count; j++)
                    {
                        res += InputSignal1.Samples[j] * InputSignal2.Samples[j];

                    }
                    for (int M = 0; M < InputSignal1.Samples.Count; M++)
                    {
                        sum_sig1 += Math.Pow((double)InputSignal1.Samples[M], 2);
                        sum_sig2 += Math.Pow((double)InputSignal2.Samples[M], 2);
                    }
                    res = res / InputSignal1.Samples.Count;

                    norm = (float)(sum_sig1 * sum_sig2);
                    norm = (float)Math.Sqrt(norm);
                    norm /= InputSignal1.Samples.Count;


                    if (InputSignal1.Periodic == false)
                    {
                        float normalize = 0;
                        for (int l = 0; l < InputSignal1.Samples.Count; l++)
                        {
                            normalize += (float)Math.Pow(InputSignal1.Samples[l], 2);

                        }
                        normalize /= InputSignal1.Samples.Count;

                        InputSignal2.Samples.RemoveAt(0);
                        InputSignal2.Samples.Add(0);

                        OutputNormalizedCorrelation.Add(res / normalize);
                        OutputNonNormalizedCorrelation.Add(res);

                    }
                    else
                    {
                        OutputNonNormalizedCorrelation.Add(res);
                        OutputNormalizedCorrelation.Add(res / norm);
                        float f = InputSignal2.Samples[0];
                        InputSignal2.Samples.RemoveAt(0);
                        InputSignal2.Samples.Add(f);
                    }

                }

            }
            else
            {
                for (int i = 0; i < InputSignal1.Samples.Count; i++)
                {
                    res = 0;
                    sum_sig1 = 0; sum_sig2 = 0; norm = 0;
                    for (int j = 0; j < InputSignal1.Samples.Count; j++)
                    {
                        res += InputSignal1.Samples[j] * InputSignal2.Samples[j];

                    }
                    for (int M = 0; M < InputSignal1.Samples.Count; M++)
                    {
                        sum_sig1 += Math.Pow((double)InputSignal1.Samples[M], 2);
                        sum_sig2 += Math.Pow((double)InputSignal2.Samples[M], 2);
                    }
                    norm = (float)(sum_sig1 * sum_sig2);
                    norm = (float)Math.Sqrt(norm);
                    norm /= InputSignal1.Samples.Count;


                    res /= InputSignal1.Samples.Count;
                    OutputNonNormalizedCorrelation.Add(res);
                    OutputNormalizedCorrelation.Add(res / norm);
                    if (InputSignal1.Periodic == true)
                    {

                        float f = InputSignal2.Samples[0];
                        InputSignal2.Samples.RemoveAt(0);
                        InputSignal2.Samples.Add(f);
                    }
                    else
                    {

                        InputSignal2.Samples.RemoveAt(0);
                        InputSignal2.Samples.Add(0);
                    }



                }

            }




        }

    }
}