﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;

namespace DSPAlgorithms.Algorithms
{
    public class MovingAverage : Algorithm
    {
        public Signal InputSignal { get; set; }
        public int InputWindowSize { get; set; }
        public Signal OutputAverageSignal { get; set; }
 
        public override void Run()
        {
            List<float> L = new List<float>();
            for (int i = InputWindowSize -1; i < InputSignal.Samples.Count ; i++)
            {
                float res = 0;
                for (int j = 0; j < InputWindowSize; j++)
                {
                    res += InputSignal.Samples[i - j];
                }
                L.Add(res/InputWindowSize);
            }
            OutputAverageSignal = new Signal(L, false);
        }
    }
}
