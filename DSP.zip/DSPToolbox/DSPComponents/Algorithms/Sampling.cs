﻿﻿using DSPAlgorithms.DataStructures;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSPAlgorithms.Algorithms
{
    public class Sampling : Algorithm
    {
        public int L { get; set; } //upsampling factor
        public int M { get; set; } //downsampling factor
        public Signal InputSignal { get; set; }
        public Signal OutputSignal { get; set; }




        public override void Run()
        {
            //Up sampling
            if (M == 0 && L != 0)
            {
                Signal s = new Signal(new List<float>(), new List<int>(),InputSignal.Periodic);
                int index=InputSignal.SamplesIndices[0];
                for (int i = 0; i < InputSignal.Samples.Count; i++)
                {
                    s.Samples.Add(InputSignal.Samples[i]);
                    s.SamplesIndices.Add(index);
                    index++;
                    for (int j = 0; j < (L-1); j++)
                    {
                        s.Samples.Add(0);
                        s.SamplesIndices.Add(index);
                        index++;
                    }
                }
                FIR MM =new FIR();
                MM.InputTimeDomainSignal = s;
                MM.InputFilterType = DSPAlgorithms.DataStructures.FILTER_TYPES.LOW;
                MM.InputFS = 8000;
                MM.InputStopBandAttenuation = 50;
                MM.InputCutOffFrequency = 1500;
                MM.InputTransitionBand = 500;
                MM.Run();

                OutputSignal = MM.OutputYn;
            }
            //Down sampling
            else if (M != 0 && L == 0)
            {

                FIR MM = new FIR();
                MM.InputTimeDomainSignal = InputSignal;
                MM.InputFilterType = DSPAlgorithms.DataStructures.FILTER_TYPES.LOW;
                MM.InputFS = 8000;
                MM.InputStopBandAttenuation = 50;
                MM.InputCutOffFrequency = 1500;
                MM.InputTransitionBand = 500;
                MM.Run();

                Signal s = new Signal(new List<float>(), new List<int>(), InputSignal.Periodic);
                int index = MM.OutputYn.SamplesIndices[0];
                for (int i = 0; i < MM.OutputYn.Samples.Count; i+=M)
                {
                    s.Samples.Add(MM.OutputYn.Samples[i]);
                    s.SamplesIndices.Add(index);
                    index++;
                }

                OutputSignal = s;
            }
            else if (M != 0 && L != 0)
            {
                //Up-sampling
                Signal s = new Signal(new List<float>(), new List<int>(), InputSignal.Periodic);
                OutputSignal= new Signal(new List<float>(), new List<int>(), InputSignal.Periodic);
                int index = InputSignal.SamplesIndices[0];
                for (int i = 0; i < InputSignal.Samples.Count; i++)
                {
                    s.Samples.Add(InputSignal.Samples[i]);
                    s.SamplesIndices.Add(index);
                    index++;
                    for (int j = 0; j < (L-1); j++)
                    {
                        s.Samples.Add(0);
                        s.SamplesIndices.Add(index);
                        index++;
                    }
                }
                //Aplly Low pass filter
                FIR MM = new FIR();
                MM.InputTimeDomainSignal = s;
                MM.InputFilterType = DSPAlgorithms.DataStructures.FILTER_TYPES.LOW;
                MM.InputFS = 8000;
                MM.InputStopBandAttenuation = 50;
                MM.InputCutOffFrequency = 1500;
                MM.InputTransitionBand = 500;
                MM.Run();

                //Down-sampling
                int ind = MM.OutputYn.SamplesIndices[0];
                for (int i = 0; i < MM.OutputYn.Samples.Count; i += M)
                {
                    OutputSignal.Samples.Add(MM.OutputYn.Samples[i]);
                    OutputSignal.SamplesIndices.Add(ind);
                    ind++;
                }
            }
            else
            {
                Console.WriteLine("Error Message!!\n");
            }


        }
    }

}