﻿using DSPAlgorithms.DataStructures;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSPAlgorithms.Algorithms
{
    public class DCT: Algorithm
    {
        public Signal InputSignal { get; set; }
        public Signal OutputSignal { get; set; }

        public override void Run()
        {
            OutputSignal = new Signal(new List<float>(), false);
            float count = InputSignal.Samples.Count;
            float res;
            float pi = (float) Math.PI;
            for (int k = 0; k < count; k++)
            {
                res = 0;
                for (int n = 0; n < count; n++)
                {
                    res += (InputSignal.Samples[n] * (float)Math.Cos((pi / (4 * count) * (2 * n - 1) * (2 * k - 1))));
                }
                res *= (float) Math.Sqrt(2 / count);
                OutputSignal.Samples.Add(res);
            }
        }
    }
}
