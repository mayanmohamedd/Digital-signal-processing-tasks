﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using DSPAlgorithms.DataStructures;
using System.Numerics;


namespace DSPAlgorithms.Algorithms
{
    public class DiscreteFourierTransform : Algorithm
    {
        public Signal InputTimeDomainSignal { get; set; }
        public float InputSamplingFrequency { get; set; }
        public Signal OutputFreqDomainSignal { get; set; }

        public override void Run()
        {
            OutputFreqDomainSignal = new Signal(new List<float>(), false, new List<float>(), 
                                                new List<float>(), new List<float>());
            float amp, phase_shift;
            for (int k = 0; k < InputTimeDomainSignal.Samples.Count; k++)
            {
                Complex c = new Complex();
                for (int n = 0; n < InputTimeDomainSignal.Samples.Count; n++)
                {
                
                    c+=new Complex(InputTimeDomainSignal.Samples[n]*(Math.Cos(-k*2*Math.PI*n/ InputTimeDomainSignal.Samples.Count)),
                                  InputTimeDomainSignal.Samples[n]*Math.Sin(-k * 2 * Math.PI * n / InputTimeDomainSignal.Samples.Count));
                     
                }
                amp = (float)Math.Sqrt(Math.Pow(c.Real, 2) + Math.Pow(c.Imaginary, 2));
                OutputFreqDomainSignal.FrequenciesAmplitudes.Add(amp);

                phase_shift = (float)Math.Atan2(c.Imaginary, c.Real);
                OutputFreqDomainSignal.FrequenciesPhaseShifts.Add(phase_shift);

            }
        }
    }
}
